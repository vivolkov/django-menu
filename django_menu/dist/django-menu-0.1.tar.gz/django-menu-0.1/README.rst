=======
MENU
=======
Django-menu is a simple Django application to form menus on a given webpage
using custom template tags.

How-to
----------
Install it like you would an ordinary Django app - run 'pip install' and then
add it to the settings file, all static files, such as templates and a .js file
are already included in the distribution.